const mongoose = require('mongoose');

const EncryptedDataSchema = new mongoose.Schema({
    data: {
        type: String,
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('EncryptedData', EncryptedDataSchema);
