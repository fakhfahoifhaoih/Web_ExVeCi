const express = require('express');
const router = express.Router();
const EncryptedData = require('../models/EncryptedData');

// Rute untuk menyimpan data terenkripsi
router.post('/', async (req, res) => {
    try {
        const { data } = req.body;
        if (!data) {
            return res.status(400).json({ error: 'Data tidak boleh kosong.' });
        }

        const encryptedData = new EncryptedData({ data });
        await encryptedData.save();
        res.status(201).json({ message: 'Data terenkripsi berhasil disimpan.', id: encryptedData._id });
    } catch (error) {
        res.status(500).json({ error: 'Terjadi kesalahan server.' });
    }
});

// Rute untuk mendapatkan semua data terenkripsi
router.get('/', async (req, res) => {
    try {
        const allData = await EncryptedData.find();
        res.status(200).json(allData);
    } catch (error) {
        res.status(500).json({ error: 'Terjadi kesalahan server.' });
    }
});

// Rute untuk mendapatkan data terenkripsi berdasarkan ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const data = await EncryptedData.findById(id);
        if (!data) {
            return res.status(404).json({ error: 'Data tidak ditemukan.' });
        }
        res.status(200).json(data);
    } catch (error) {
        res.status(500).json({ error: 'Terjadi kesalahan server.' });
    }
});

// Rute untuk menghapus data berdasarkan ID
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const data = await EncryptedData.findByIdAndDelete(id);
        if (!data) {
            return res.status(404).json({ error: 'Data tidak ditemukan.' });
        }
        res.status(200).json({ message: 'Data berhasil dihapus.' });
    } catch (error) {
        res.status(500).json({ error: 'Terjadi kesalahan server.' });
    }
});

module.exports = router;
